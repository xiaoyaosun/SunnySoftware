<?php

set_time_limit(600); //set timeout to 10 minutes, or you can set max_execution_time in php.ini
date_default_timezone_set('America/Los_Angeles');

$account = '<your media services account name>';
$secret = '<your media services account key>';
