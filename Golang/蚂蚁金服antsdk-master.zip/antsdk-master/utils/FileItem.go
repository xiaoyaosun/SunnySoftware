package utils

type FileItem struct {
  FileName string
  MimeType string
  Content []byte
}
