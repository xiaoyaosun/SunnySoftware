package data

import (
  "github.com/LayGit/antsdk/api"
)

type KoubeiMarketingCampaignCrowdModifyResponse struct {
  api.AlipayResponse
}
