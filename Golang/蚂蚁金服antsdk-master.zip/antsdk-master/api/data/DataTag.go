package data

type DataTag struct {
  Code string `json:"code"`
  Aggregate string `json:"aggregate"`
  Alias string `json:"alias"`
}
