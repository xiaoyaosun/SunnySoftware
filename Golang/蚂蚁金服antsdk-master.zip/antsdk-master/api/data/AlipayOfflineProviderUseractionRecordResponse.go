package data

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOfflineProviderUseractionRecordResponse struct {
  api.AlipayResponse
}
