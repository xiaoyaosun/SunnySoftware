package data

import (
  "github.com/LayGit/antsdk/api"
)

type KoubeiMarketingDataCustomreportDeleteResponse struct {
  api.AlipayResponse
}
