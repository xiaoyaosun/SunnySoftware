package data

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOfflineProviderShopactionRecordResponse struct {
  api.AlipayResponse
}
