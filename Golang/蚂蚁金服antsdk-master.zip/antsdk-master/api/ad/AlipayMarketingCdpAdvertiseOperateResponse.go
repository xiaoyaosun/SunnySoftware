package ad

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayMarketingCdpAdvertiseOperateResponse struct {
  api.AlipayResponse
}
