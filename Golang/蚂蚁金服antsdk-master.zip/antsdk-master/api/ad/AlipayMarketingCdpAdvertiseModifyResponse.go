package ad

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayMarketingCdpAdvertiseModifyResponse struct {
  api.AlipayResponse
}
