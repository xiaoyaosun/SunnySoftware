package trade

type SubMerchant struct {
  MerchantId  string  `json:"merchant_id"`  // 二级商户的支付宝id
}
