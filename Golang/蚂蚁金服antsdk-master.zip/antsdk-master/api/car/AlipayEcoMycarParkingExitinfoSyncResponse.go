package car

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayEcoMycarParkingExitinfoSyncResponse struct {
  api.AlipayResponse
}
