package car

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayEcoMycarParkingOrderUpdateResponse struct {
  api.AlipayResponse
}
