package car

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayEcoMycarParkingParkinglotinfoUpdateResponse struct {
  api.AlipayResponse
}
