package marketing

type ClauseTerm struct {
  Title         string    `json:"title"`        // 说明title
  Descriptions  []string  `json:"descriptions"` // 说明描述内容
}
