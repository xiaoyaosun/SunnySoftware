package marketing

type BudgetInfo struct {
  BudgetType  string `json:"budget_type"`   // 预算类型
  BudgetTotal string `json:"budget_total"`  // 预算数量
}
