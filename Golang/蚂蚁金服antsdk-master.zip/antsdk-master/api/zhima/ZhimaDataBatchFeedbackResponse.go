package zhima

import (
  "github.com/LayGit/antsdk/api"
)

type ZhimaDataBatchFeedbackResponse struct {
  api.AlipayResponse
}
