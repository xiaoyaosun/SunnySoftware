package util

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayUserInfoAuthResponse struct {
  api.AlipayResponse
}
