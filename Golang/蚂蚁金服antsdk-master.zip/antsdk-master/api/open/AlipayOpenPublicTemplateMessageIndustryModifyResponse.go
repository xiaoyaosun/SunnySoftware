package open

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenPublicTemplateMessageIndustryModifyResponse struct {
  api.AlipayResponse
}
