package open

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenPublicMenuModifyResponse struct {
  api.AlipayResponse
}
