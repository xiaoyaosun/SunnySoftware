package open

type Text struct {
  Content string `json:"content"` // 文本消息内容
}
