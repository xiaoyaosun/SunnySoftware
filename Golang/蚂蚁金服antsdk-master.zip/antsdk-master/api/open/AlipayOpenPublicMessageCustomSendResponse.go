package open

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenPublicMessageCustomSendResponse struct {
  api.AlipayResponse
}
