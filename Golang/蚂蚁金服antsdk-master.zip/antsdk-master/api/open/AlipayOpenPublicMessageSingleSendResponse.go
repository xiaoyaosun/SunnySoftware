package open

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenPublicMessageSingleSendResponse struct {
  api.AlipayResponse
}
