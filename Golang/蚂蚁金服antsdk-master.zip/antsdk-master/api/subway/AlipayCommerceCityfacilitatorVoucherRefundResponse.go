package subway

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayCommerceCityfacilitatorVoucherRefundResponse struct {
  api.AlipayResponse
}
