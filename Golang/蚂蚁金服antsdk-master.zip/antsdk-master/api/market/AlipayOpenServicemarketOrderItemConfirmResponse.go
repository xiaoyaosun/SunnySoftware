package market

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenServicemarketOrderItemConfirmResponse struct {
  api.AlipayResponse
}
