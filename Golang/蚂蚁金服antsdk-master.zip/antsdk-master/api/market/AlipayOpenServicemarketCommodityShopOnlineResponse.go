package market

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenServicemarketCommodityShopOnlineResponse struct {
  api.AlipayResponse
}
