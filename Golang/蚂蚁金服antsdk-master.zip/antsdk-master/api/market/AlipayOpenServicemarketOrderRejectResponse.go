package market

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenServicemarketOrderRejectResponse struct {
  api.AlipayResponse
}
