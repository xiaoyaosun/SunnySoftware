package market

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenServicemarketCommodityShopOfflineResponse struct {
  api.AlipayResponse
}
