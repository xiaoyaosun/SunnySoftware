package market

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenServicemarketOrderItemCancelResponse struct {
  api.AlipayResponse
}
