package market

import (
  "github.com/LayGit/antsdk/api"
)

type AlipayOpenServicemarketOrderNotifyResponse struct {
  api.AlipayResponse
}
